# Dojo Secrets

A Django app where users can login and post secrets anonymously. There's a most popular page that shows the secrets most liked by users and users are able to delete secrets they've posted.

__Built With:__ 
  * Python / Django
  * HTML/CSS
  * Bootstrap

![Dojo Secrets](https://github.com/Ziyal/DojoSecrets/blob/master/screenshots/dojosecrets1.png "Dojo Secrets")

![Dojo Secrets](https://github.com/Ziyal/DojoSecrets/blob/master/screenshots/dojosecrets3.png "Dojo Secrets")

![Dojo Secrets](https://github.com/Ziyal/DojoSecrets/blob/master/screenshots/dojosecrets2.png "Dojo Secrets")
